# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


def getMatrix(df, year_before=2010, year_after=2011):
    status_before = df[df.index == year_before].values
    status_after = df[df.index == year_after].values
    status_pinv = np.linalg.pinv(status_before)

    # dot
    transfer_matrix = np.dot(status_pinv, status_after)

    return transfer_matrix


def getMeanMatrix(df):

    matrix_list = []
    for year in range(2010, 2016+1):
        res = getMatrix(df, year, year+1)
        matrix_list.append(res)

    matrix_list = np.asarray(matrix_list)
    matrix_mean = matrix_list.mean(axis=0)

    return matrix_mean


if __name__ == "__main__":
    ['KY', 'OH', 'PA', 'VA', 'WV']
    states = ['Kentucky', 'Ohio', 'Pennsylvania', 'Virginia', 'West Virginia']

    df_heroin = pd.read_excel('data/county_heroin.xlsx', index_col=0)
    df_nonheroin = pd.read_excel('data/county_nonheroin.xlsx', index_col=0)

    df_heroin_matrix = getMeanMatrix(df_heroin)
    df_nonheroin_matrix = getMeanMatrix(df_nonheroin)

    df_heroin_matrix = pd.DataFrame(
        df_heroin_matrix, index=df_heroin.columns, columns=df_heroin.columns)

    df_nonheroin_matrix = pd.DataFrame(
        df_nonheroin_matrix, index=df_nonheroin.columns, columns=df_nonheroin.columns)
